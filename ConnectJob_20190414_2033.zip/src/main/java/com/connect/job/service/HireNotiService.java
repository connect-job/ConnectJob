package com.connect.job.service;

import java.util.List;

import com.connect.job.model.vo.HireNoti;


public interface HireNotiService {
	
	/*int insertNoti(HireNoti h,List<HireNoti> list );*/
	int insertNoti(HireNoti h);

}
