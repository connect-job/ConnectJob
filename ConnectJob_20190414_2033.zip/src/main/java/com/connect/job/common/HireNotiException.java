package com.connect.job.common;

public class HireNotiException extends RuntimeException {
	
	public HireNotiException() {
		super();
	}
	public HireNotiException(String msg)
	{
		super(msg);
	}

}