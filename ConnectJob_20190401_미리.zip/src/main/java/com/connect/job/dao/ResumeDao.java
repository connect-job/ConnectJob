package com.connect.job.dao;

import com.connect.job.model.vo.Career;
import com.connect.job.model.vo.FinalEdu;
import com.connect.job.model.vo.Resume;

public interface ResumeDao {
	int insertResume(Resume r);
	int insertFinalEdu(FinalEdu fe);
	int insertCareer(Career c);
}
