package com.connect.job.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.connect.job.model.vo.Career;
import com.connect.job.model.vo.FinalEdu;
import com.connect.job.model.vo.Resume;

@Repository
public class ResumeDaoImpl implements ResumeDao {
	@Autowired
	private SqlSessionTemplate session;

	@Override
	public int insertResume(Resume r) {
		return session.insert("resume.insertResume",r);
	}

	@Override
	public int insertFinalEdu(FinalEdu fe) {
		return session.insert("finalEdu.insertFinalEdu",fe);
	}

	@Override
	public int insertCareer(Career c) {
		return session.insert("career.insertCareer",c);
	}
	
	
}
