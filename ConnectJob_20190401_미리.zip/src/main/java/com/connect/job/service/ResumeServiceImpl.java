package com.connect.job.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.connect.job.dao.ResumeDao;
import com.connect.job.model.vo.Career;
import com.connect.job.model.vo.FinalEdu;
import com.connect.job.model.vo.Resume;

@Service
public class ResumeServiceImpl implements ResumeService {
	@Autowired
	private ResumeDao dao;
	
	@Override
	public int insertResume(Resume r) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertFinalEdu(FinalEdu fe) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertCareer(Career c) {
		// TODO Auto-generated method stub
		return 0;
	}

}
