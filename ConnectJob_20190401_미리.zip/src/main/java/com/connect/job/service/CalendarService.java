package com.connect.job.service;

public interface CalendarService {

}
