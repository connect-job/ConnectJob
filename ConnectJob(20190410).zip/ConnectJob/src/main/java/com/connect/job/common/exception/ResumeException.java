package com.connect.job.common.exception;

public class ResumeException extends RuntimeException {
	public ResumeException() {
		super();
	}
	public ResumeException(String msg) {
		super(msg);
	}
}
