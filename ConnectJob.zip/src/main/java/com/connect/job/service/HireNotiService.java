package com.connect.job.service;

import com.connect.job.model.vo.HireNoti;

public interface HireNotiService {
	
	int insertNoti(HireNoti h);

}
