package com.connect.job.service;

import com.connect.job.model.vo.Message;

public interface MessageService {

	Message messageCount(Message m);

}
