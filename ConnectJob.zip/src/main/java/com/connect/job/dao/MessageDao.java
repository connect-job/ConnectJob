package com.connect.job.dao;

import com.connect.job.model.vo.Message;

public interface MessageDao {

	Message messageCount(Message m);

}
