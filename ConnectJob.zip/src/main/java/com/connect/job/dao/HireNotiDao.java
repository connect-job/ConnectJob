package com.connect.job.dao;

import com.connect.job.model.vo.HireNoti;

public interface HireNotiDao {

	int insertNoti(HireNoti h);

}
